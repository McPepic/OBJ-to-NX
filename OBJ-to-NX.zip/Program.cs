﻿using System.Text.RegularExpressions;

public class OBJtoNX
{
    public static void Main(string[] args) {
        string[] objFiles = Directory.GetFiles(".", "*.obj");
        if (objFiles.Length == 0) {
            Console.WriteLine("No Object File Found!");
            Console.WriteLine($"Make sure the .obj file is in: '{Directory.GetCurrentDirectory()}'");

            Console.ReadLine();
            return;
        }

        List<Vertex> vertices = new List<Vertex>();
        List<Triangle> triangles = new List<Triangle>();

        float bound = 0;

        string[] lines = File.ReadAllLines($@"{Directory.GetCurrentDirectory()}\{objFiles[0]}");
        foreach (string line in lines) {
            string[] words = Regex.Replace(line, @"\s+", " ").Split(' ');
            if (words[0] == "v") {
                float x = float.Parse(words[1]);
                float y = float.Parse(words[2]);
                float z = float.Parse(words[3]);
                vertices.Add(new Vertex(x, y, z));

                if (Math.Abs(x) > bound) bound = Math.Abs(x);
                if (Math.Abs(y) > bound) bound = Math.Abs(y);
                if (Math.Abs(z) > bound) bound = Math.Abs(z);
            }
            if (words[0] == "f") {
                int v1 = int.Parse(words[1].Substring(0, words[1].IndexOf('/')));
                int v2 = int.Parse(words[2].Substring(0, words[2].IndexOf('/')));
                int v3 = int.Parse(words[3].Substring(0, words[3].IndexOf('/')));
                triangles.Add(new Triangle(v1, v2, v3));
            }
        }

        if (bound >= 4) {
            foreach (Vertex vertex in vertices) {
                vertex.x = vertex.x / bound * 3.99988f;
                vertex.y = vertex.y / bound * 3.99988f;
                vertex.z = vertex.z / bound * 3.99988f;
            }
        }

        int vCount = vertices.Count;
        int fCount = triangles.Count;

        string vData = "";
        foreach (Vertex vertex in vertices) {
            vData += ((short)(vertex.x * 8192)).ToString("X4");
            vData += ((short)(vertex.y * 8192)).ToString("X4");
            vData += ((short)(vertex.z * 8192)).ToString("X4");
        }

        string fData = "";
        foreach (Triangle triangle in triangles) {
            fData += triangle.v1.ToString("X4");
            fData += triangle.v2.ToString("X4");
            fData += triangle.v3.ToString("X4");
        }

        Console.WriteLine($"VQTY = {vCount}");
        Console.WriteLine($"V$ = \"{vData}\"");
        Console.WriteLine($"FQTY = {fCount}");
        Console.WriteLine($"F$ = \"{fData}\"");

        Console.ReadLine();
    }
}

public class Vertex
{
    public float x, y, z;
    public Vertex(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
}

public class Triangle
{
    public int v1, v2, v3;
    public Triangle(int v1, int v2, int v3) {
        this.v1 = v1;
        this.v2 = v2;
        this.v3 = v3;
    }
}